package com.hms;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Department {
	@Id
	@Column(name = "Department_Div", length = 50,nullable = false)
	private String department_div;
	@Column(name = "Budget", length = 100,nullable = false)
	private String budget;
	
	
	
	//Setter And Getter
	public String getDepartment_Div() {
		return department_div;
	}
	public void setDepartment_Div(String department_div) {
		this.department_div = department_div;
	}
	public String getBudget() {
		return budget;
	}
	public void setBudget(String budget) {
		this.budget = budget;
	}
	
	//All argument Constructor
	public Department (String department_div, String budget) {
		super();
		this.department_div = department_div;
		this.budget = budget;
		
		
	}
	//Default Constructor
	public Department() {
		super();
	}
	//ToString method
	@Override
	public String toString() {
		return "Department [department_div=" + department_div + ", budget=" + budget + "]";
	}
}
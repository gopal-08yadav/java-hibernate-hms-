package com.hms.Dao;


import com.hms.Employees;
import java.util.List;

public interface EmployeesDao {
    // Create
	Employees createEmployee(Employees employee);
    
    // Read
    Employees getEmployeeByAadhar(String emp_aadhar);
    
    // Update
    Employees updateEmployee(String emp_aadhar);
    Employees updatedEmployee(String emp_aadhar,Employees updatedemployee);
    
    // Delete
    Employees deleteEmployee(String emp_aadhar);
    
    // List all employees
    List<Employees> getAllEmployees();
}

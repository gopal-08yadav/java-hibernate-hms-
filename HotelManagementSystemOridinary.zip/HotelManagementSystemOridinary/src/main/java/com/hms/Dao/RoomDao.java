package com.hms.Dao;

import java.util.List;

import com.hms.Room;

public interface RoomDao {
    Room getRoomByNumber(String roomNumber);
    Room saveRoom(Room room);
    Room updateRoom(String roomNumber,Room room);
    Room deleteRoom(String roomNumber);
	List<Room> getAllRooms();
	
}

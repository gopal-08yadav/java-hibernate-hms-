package com.hms.Dao;



import com.hms.Department;
import java.util.List;

public interface DepartmentDao {
    // Create
	Department createDepartment(Department department);
    
    // Read
    Department getDepartmentById(String department_div);
    
    // Update
    Department updateDepartment(String department_div,Department department);
    
    // Delete
    Department deleteDepartment(String department_div);
    
    // List all departments
    List<Department> getAllDepartments();
}


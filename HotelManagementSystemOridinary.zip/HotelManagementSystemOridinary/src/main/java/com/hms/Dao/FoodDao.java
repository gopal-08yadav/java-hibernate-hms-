package com.hms.Dao;

import com.hms.Food;

import java.util.List;

public interface FoodDao {
	Food createFood(Food food);
    Food updateFood(String foodId,Food food);
    Food deleteFood(String foodId);
    Food getFoodById(String foodId);
    List<Food> getAllFoods();
}

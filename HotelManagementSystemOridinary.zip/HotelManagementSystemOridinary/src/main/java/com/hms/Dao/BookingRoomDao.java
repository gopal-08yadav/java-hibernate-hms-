package com.hms.Dao;


import java.util.List;
import java.util.Optional;

import com.hms.BookingRoom;

public interface BookingRoomDao {
    void save(BookingRoom bookingRoom);
    Optional<BookingRoom> findById(String bookingId);
    void update(BookingRoom bookingRoom);
    void delete(String bookingId);
	List<BookingRoom> get();
}

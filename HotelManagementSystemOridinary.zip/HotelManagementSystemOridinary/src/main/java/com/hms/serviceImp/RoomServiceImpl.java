package com.hms.serviceImp;

import java.util.List;

import com.hms.Room;
import com.hms.Dao.RoomDao;
import com.hms.DaoImp.RoomDaoImpl;
import Services.RoomService;

public class RoomServiceImpl implements RoomService {

    private RoomDao roomDao = new RoomDaoImpl();

    @Override
    public Room getRoomByNumber(String roomNumber) {
        return roomDao.getRoomByNumber(roomNumber);
    }

    @Override
    public Room createRoom(Room room) {
        roomDao.saveRoom(room);
        System.out.println("Room created successfully.");
		return room;
    }

    @Override
    public Room updateRoom(String roomNumebr,Room room) {
        roomDao.updateRoom(roomNumebr,room);
        System.out.println("Room updated successfully.");
		return room;
    }

    @Override
    public String deleteRoom(String roomNumber) {
        roomDao.deleteRoom(roomNumber);
        System.out.println("Room deleted successfully.");
		return roomNumber;
    }

	@Override
	public Room addRoom(Room room) {
		//roomDao.addRoom(roomNumber);
		return room;
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Room> getAllRooms() {
		// TODO Auto-generated method stub
		return  roomDao.getAllRooms();
	}

}

package com.hms.serviceImp;




import com.hms.Department;
import com.hms.Dao.CustomerDao;
import com.hms.Dao.DepartmentDao;
import com.hms.DaoImp.CustomerDaoImpl;
import com.hms.DaoImp.DepartmentDaoImpl;
import Services.DepartmentService;

import java.util.List;

public class DepartmentServiceImpl implements DepartmentService {

	DepartmentDao departmentDao =new DepartmentDaoImpl();

    @Override
    public Department createDepartment(Department department) {
        return departmentDao.createDepartment(department);
    }

    @Override
    public Department getDepartmentById(String department_div) {
        return departmentDao.getDepartmentById(department_div);
    }

    @Override
    public Department updateDepartment(String department_div,Department department) {
        return departmentDao.updateDepartment(department_div, department);
    }

    @Override
    public String deleteDepartment(String department_div) {
        departmentDao.deleteDepartment(department_div);
		return department_div;
    }

    @Override
    public List<Department> getAllDepartments() {
        return departmentDao.getAllDepartments();
    }


}

package com.hms.serviceImp;

import java.util.List;  
import java.time.LocalDate;

import com.hms.BookingRoom;
import com.hms.Dao.BookingRoomDao;
import com.hms.DaoImp.BookingRoomDaoImpl;


import Services.BookingRoomService;

import java.util.Optional;

public class BookingRoomServiceImpl implements BookingRoomService {

    private BookingRoomDao bookingRoomDAO = new BookingRoomDaoImpl();

    @Override
    public void createBookingRoom(BookingRoom bookingRoom) {
        bookingRoomDAO.save(bookingRoom);
    }

    @Override
    public Optional<BookingRoom> getBookingRoomById(String bookingId) {
        return bookingRoomDAO.findById(bookingId);
    }

    @Override
    public void updateBookingRoom(BookingRoom bookingRoom) {
        bookingRoomDAO.update(bookingRoom);
    }

    @Override
    public void deleteBookingRoom(String bookingId) {
        bookingRoomDAO.delete(bookingId);
    }

	@Override
	public List<BookingRoom> getAllBookingRooms() {
		// TODO Auto-generated method stub
		return bookingRoomDAO.get();
	}
}

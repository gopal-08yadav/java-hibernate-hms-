package com.hms.DaoImp;


import com.hms.Customers;

import com.hms.Dao.CustomerDao;
import com.hms.util.HibernateUtil;
//import com.student.entity.Student;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class CustomerDaoImpl implements CustomerDao {
	 Scanner sc=new Scanner(System.in);
	@Override
	public Customers createCustomers(Customers customers) {
	
			try(Session session=HibernateUtil.getSession()) {
				
				session.beginTransaction();
				session.save(customers);
				session.getTransaction().commit();
				return customers;
				
			}
			catch (HibernateException e) {
				System.out.println(e);
			}
			catch (Exception e) {
				System.out.println(e);
			}
			
			return null;
		}

	 @Override
	    public Optional<Customers> findById(Long cust_id) {
	        Customers customer = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            customer = session.get(Customers.class, cust_id);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return Optional.ofNullable(customer);
	    }
	@Override
	public Customers getCustomers(Long cust_id) {
		
			try(Session session=HibernateUtil.getSession()) {
					
				Customers student=session.get(Customers.class, cust_id);
					return student;
				}
				catch (HibernateException e) {
					System.out.println(e);
				}
				catch (Exception e) {
					System.out.println(e);
				}
				
				return null;
			}
	@Override
	public List<Customers> getAllCustomers() {
		try(Session session=HibernateUtil.getSession()) {
			
			//execute HQL query to retrieve all students data
			Query<Customers> query=session.createQuery("FROM Customers");
			List<Customers> customersList=query.list();
			return customersList;
			
		}
		catch (HibernateException e) {
			System.out.println(e);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		return null;
	}


	@Override
	public Customers updateCustomers(Long cust_id, Customers updatedCustomers) {
	    try (Session session = HibernateUtil.getSession()) {
	        // Fetch the customer entity by ID
	        Customers customer = session.get(Customers.class, cust_id);

	        if (customer != null) {
	            session.beginTransaction();

	            // Update customer details
	            customer.setCustName(updatedCustomers.getCustName());
	            customer.setCustGender(updatedCustomers.getCustGender());
	            customer.setCustNumber(updatedCustomers.getCustNumber());
	            customer.setRoomNumber(updatedCustomers.getRoomNumber());
	            customer.setDeposit(updatedCustomers.getDeposit());
	            customer.setCountry(updatedCustomers.getCountry());
	            customer.setFoodId(updatedCustomers.getFoodId());
	            customer.setCheckInTime(updatedCustomers.getCheckInTime());

	            session.saveOrUpdate(customer);  // Save or update the customer
	            session.getTransaction().commit();

	            return customer;
	        } else {
	            System.out.println("Customer with ID '" + cust_id + "' not found!");
	            return null;
	        }
	    } catch (HibernateException e) {
	        System.out.println(e);
	    } catch (Exception e) {
	        System.out.println(e);
	    }
	    return null;
	}


    // Other methods...

	@Override
	public String deleteCustomers(Long cust_id) {
	    String message = null;
	    try (Session session = HibernateUtil.getSession()) {
	        // Fetch the customer entity by ID
	        Customers customer = session.get(Customers.class, cust_id);

	        if (customer != null) {
	            session.beginTransaction();
	            System.out.println("Are you sure you want to delete?");
	            String status = sc.nextLine();
	            if (status.equalsIgnoreCase("yes")) {
	                session.delete(customer);  // Data will be deleted from DB
	                session.getTransaction().commit();
	                session.evict(customer);  // Data will be removed from session cache
	                message = "Customer is deleted";
	            } else {
	                message = "User wants to retain this customer!";
	            }
	        } else {
	            message = "Customer with Id '" + cust_id + "' not found!";
	        }
	    } catch (HibernateException e) {
	        System.out.println(e);
	        message = "An error occurred while deleting the customer.";
	    } catch (Exception e) {
	        System.out.println(e);
	        message = "An unexpected error occurred.";
	    }
	    return message;
	}


}

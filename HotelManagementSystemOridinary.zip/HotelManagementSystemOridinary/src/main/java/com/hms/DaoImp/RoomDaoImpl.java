package com.hms.DaoImp;

import com.hms.Customers;
import com.hms.Room;
import com.hms.Dao.RoomDao;
import com.hms.util.HibernateUtil;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;

public class RoomDaoImpl implements RoomDao {
	Scanner sc=new Scanner(System.in);
    @Override
    public Room getRoomByNumber(String roomNumber) {
    	try(Session session=HibernateUtil.getSession()) {
			
			Room room=session.get(Room.class, roomNumber);
				return room;
			}
			catch (HibernateException e) {
				System.out.println(e);
			}
			catch (Exception e) {
				System.out.println(e);
			}
			
			return null;
    }

    @Override
    public Room saveRoom(Room room) {
    	try(Session session=HibernateUtil.getSession()) {
			
			session.beginTransaction();
			session.save(room);
			session.getTransaction().commit();
			return room;
			
		}
		catch (HibernateException e) {
			System.out.println(e);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		return null;
    }

    @Override
    public Room updateRoom(String roomnumber,Room updatedroom) {
    	try(Session session=HibernateUtil.getSession()) {
    		Room rooms=session.get(Room.class, roomnumber);
				session.beginTransaction();
				
				rooms.setRoomNumber(roomnumber);
				rooms.setAvailability(updatedroom.getAvailability());
				rooms.setCleanStatus(updatedroom.getCleanStatus());
				rooms.setPrice(updatedroom.getPrice());
				rooms.setBedType(updatedroom.getBedType());
				
				
				session.saveOrUpdate(rooms);
				session.getTransaction().commit();
				return rooms;
				}
			
    }

    @Override
    public Room deleteRoom(String roomNumber) {
    	String message=null;
		try(Session session=HibernateUtil.getSession()) {
			Customers customers=session.get(Customers.class, roomNumber);
				session.beginTransaction();
				System.out.println("Are you sure  you want to delete?");
				String status=sc.next();
				if(status.equalsIgnoreCase("yes"))
				{
					session.delete(customers);//data will be deleted from DB
					session.getTransaction().commit();
					session.evict(customers);//data will remove from session Cache
					message="Object is deleted";
					
				}else
				{
					message="User wants to retain this object!!";
				}
		}
		catch (HibernateException e) {
			System.out.println(e);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return null;
		
    }

	@Override
	public List<Room> getAllRooms() {
try(Session session=HibernateUtil.getSession()) {
			
			//execute HQL query to retrieve all students data
			Query<Room> query=session.createQuery("FROM Room");
			List<Room> roomsList=query.list();
			return roomsList;
			
		}
		catch (HibernateException e) {
			System.out.println(e);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		return null;
	}
}

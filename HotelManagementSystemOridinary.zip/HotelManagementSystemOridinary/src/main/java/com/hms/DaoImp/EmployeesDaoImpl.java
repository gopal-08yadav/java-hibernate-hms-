package com.hms.DaoImp;



import com.hms.Employees;
import com.hms.Dao.EmployeesDao;
import com.hms.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import java.util.List;

public class EmployeesDaoImpl implements EmployeesDao {

    @Override
    public Employees createEmployee(Employees employee) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(employee);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
		return null;
    }

    @Override
    public Employees getEmployeeByAadhar(String emp_aadhar) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Employees.class, emp_aadhar);
        }
    }

    @Override
    public Employees updatedEmployee(String emp_aadhar,Employees updatedEmployee) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(updatedEmployee);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
		return null;
    }

    @Override
    public Employees deleteEmployee(String emp_aadhar) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Employees employee = session.get(Employees.class, emp_aadhar);
            if (employee != null) {
                session.delete(employee);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
		return null;
    }

    @Override
    public List<Employees> getAllEmployees() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Employees> query = session.createQuery("from Employees", Employees.class);
            return query.list();
        }
    }

	@Override
	public Employees updateEmployee(String emp_aadhar) {
		// TODO Auto-generated method stub
		return null;
	}
}

package com.hms.association;

public class ManytoOne {

}

package com.hms;

import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class BookingRoom {
    @Id
    @Column(length = 50, nullable = false)
    private String bookingId;

    @Column(nullable = false)
    private LocalDate checkInDate;

    @Column(nullable = false)
    private LocalDate checkOutDate;

    @Column
    private LocalDate bookingDate = LocalDate.now();

    @ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinColumn(name = "CustomerID")
    private Customers customer; // Foreign key in DB, but Hibernate will hold customer object

    @ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinColumn(name = "RoomNumber")
    private Room room;

    @ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinColumn(name = "Food_Id")
    private Food food;

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Customers getCustomer() {
        return customer;
    }

    public void setCustomer(Customers customer) {
        this.customer = customer;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    // Constructors
    public BookingRoom() {
        super();
    }

    public BookingRoom(String bookingId, Customers customer, Room room, Food food) {
        this.bookingId = bookingId;
        this.customer = customer;
        this.room = room;
        this.food = food;
    }

    public BookingRoom(String bookingId, Long cust_name, String roomNumber, 
                       LocalDate checkInDate, LocalDate checkOutDate) {
        this.bookingId = bookingId;
        // You need to fetch the Customer and Room entities using the IDs
        // This constructor should not be used as-is for entity relationships
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    @Override
    public String toString() {
        return "BookingRoom [bookingId=" + bookingId + ", bookingDate=" + bookingDate + ", customer=" + customer
                + ", room=" + room + ", food=" + food + "]";
    }
}

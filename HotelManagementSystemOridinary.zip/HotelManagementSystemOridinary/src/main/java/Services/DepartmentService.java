package Services;


import com.hms.Department;
import java.util.List;

public interface DepartmentService {
    // Create
	Department createDepartment(Department department);
    
    // Read
    Department getDepartmentById(String departmentId);
    
    // Update
    Department updateDepartment(String departmentId, Department updatedDepartment);
    
    // Delete
    String deleteDepartment(String departmentId);
    
    // List all departments
    List<Department> getAllDepartments();

	

	
}


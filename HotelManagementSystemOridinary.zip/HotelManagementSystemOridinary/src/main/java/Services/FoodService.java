package Services;



import com.hms.Food;
import java.util.List;

public interface FoodService {
    Food createFood(Food food);
    Food getFood(String foodId);
    String deleteFood(String foodId);
    List<Food> getAllFoods();
	Food getFoodById(String foodId);
	Food updateFood(String foodId, Food updatedFood);
}


package Services;


import java.util.List;

import com.hms.Room;

public interface RoomService {
    Room getRoomByNumber(String roomNumber);
    Room createRoom(Room room);
    //Room updateRoom(Room room);
    Room updateRoom(String roomNumber,Room updatedRoom);
    String deleteRoom(String roomNumber);
    Room addRoom(Room room);
	List<Room> getAllRooms();
}

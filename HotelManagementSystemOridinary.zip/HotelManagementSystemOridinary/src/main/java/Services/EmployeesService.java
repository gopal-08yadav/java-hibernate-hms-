package Services;


import com.hms.Employees;
import java.util.List;

public interface EmployeesService {
    // Create
    Employees createEmployee(Employees employees);
    
    // Read
    Employees getEmployeeByAadhar(String emp_aadhar);
    
    // Update
    Employees updatedEmployee(String employeeId);

    // Delete
    String deleteEmployee(String emp_aadhar);
    
    // List all employees
    List<Employees> getAllEmployees();

	Employees updatedEmployee(String emp_aadhar, Employees updatedEmployee);

	

	
	
}

package Services;



import java.util.List;
import com.hms.BookingRoom;

import java.util.Optional;

public interface BookingRoomService {
    void createBookingRoom(BookingRoom bookingRoom);
    Optional<BookingRoom> getBookingRoomById(String bookingId);
    void updateBookingRoom(BookingRoom bookingRoom);
    void deleteBookingRoom(String bookingId);
	List<BookingRoom> getAllBookingRooms();
}


